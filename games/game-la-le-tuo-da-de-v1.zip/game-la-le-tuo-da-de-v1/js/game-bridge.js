(function () {
  "use strict";

  const HOST_SOURCE = "panpan-host";
  const GAME_SOURCE = "panpan-game";
  const PROTOCOL_VERSION = "1.0";

  let hostConfig = {
    muted: false,
    adsEnabled: false
  };

  function send(type, payload) {
    try {
      window.parent.postMessage(
        {
          source: GAME_SOURCE,
          version: PROTOCOL_VERSION,
          type,
          payload: payload || {}
        },
        "*"
      );
    } catch (error) {
      console.warn("PanPanGame postMessage failed", error);
    }
  }

  function onHostMessage(event) {
    const message = event.data;
    if (!message || message.source !== HOST_SOURCE) return;
    if (message.version !== PROTOCOL_VERSION) return;

    switch (message.type) {
      case "HOST_INIT":
        hostConfig = { ...hostConfig, ...(message.payload || {}) };
        window.dispatchEvent(new CustomEvent("panpan:host-init", { detail: hostConfig }));
        break;
      case "HOST_PAUSE":
        window.dispatchEvent(new CustomEvent("panpan:pause"));
        break;
      case "HOST_RESUME":
        window.dispatchEvent(new CustomEvent("panpan:resume"));
        break;
      case "AUDIO_CHANGE":
        hostConfig.muted = Boolean(message.payload && message.payload.muted);
        window.dispatchEvent(new CustomEvent("panpan:audio-change", { detail: { muted: hostConfig.muted } }));
        break;
      case "AD_RESULT":
        window.dispatchEvent(new CustomEvent("panpan:ad-result", { detail: message.payload || {} }));
        break;
      default:
        break;
    }
  }

  window.addEventListener("message", onHostMessage);

  window.PanPanGame = {
    send,
    ready(payload) { send("GAME_READY", payload); },
    start(payload) { send("GAME_START", payload); },
    pause(payload) { send("GAME_PAUSE", payload); },
    resume(payload) { send("GAME_RESUME", payload); },
    score(payload) { send("SCORE_UPDATE", payload); },
    levelComplete(payload) { send("LEVEL_COMPLETE", payload); },
    end(payload) { send("GAME_END", payload); },
    error(payload) { send("GAME_ERROR", payload); },
    requestAd(payload) { send("AD_REQUEST", payload); },
    getHostConfig() { return { ...hostConfig }; }
  };
})();
