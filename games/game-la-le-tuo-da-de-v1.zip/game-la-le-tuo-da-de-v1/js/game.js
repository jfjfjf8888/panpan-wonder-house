(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const canvas = $('#gameCanvas');
  const ctx = canvas && canvas.getContext ? canvas.getContext('2d') : null;
  if (!ctx) {
    window.PanPanGame?.error({ code:'CANVAS_INIT_FAILED', message:'Canvas 2D 初始化失败', fatal:true });
    throw new Error('Canvas 2D 初始化失败');
  }
  const W = canvas.width, H = canvas.height;
  const START_X = 70, START_Y = 438;
  document.addEventListener('contextmenu',e=>e.preventDefault());
  document.addEventListener('selectstart',e=>e.preventDefault());

  const foods = [
    {id:'latte', icon:'☕', name:'小油油拿铁', desc:'奶油推进，冲得远'},
    {id:'prune', icon:'🫐', name:'西梅汁', desc:'紫色瀑布，速度快'},
    {id:'banana', icon:'🍌', name:'香蕉', desc:'顺滑柔软，弹性好'},
    {id:'yogurt', icon:'🥛', name:'酸奶', desc:'发酵气泡，弹弹弹'},
    {id:'yam', icon:'🍠', name:'烤红薯', desc:'体积巨大，抗风强'},
    {id:'corn', icon:'🌽', name:'玉米', desc:'颗粒装甲，更耐撞'},
    {id:'hotpot', icon:'🌶️', name:'麻辣火锅', desc:'火焰爆破，可破纸'},
    {id:'soda', icon:'🥤', name:'冰汽水', desc:'气体推进，滞空久'}
  ];

  const types = {
    normal:{id:'normal',name:'普通便便',tag:'朴实无华，但很好控制',body:'#795033',accent:'#4d2f20',speed:1,weight:1,bounce:.35,shape:'swirl',trail:'dust'},
    rocket:{id:'rocket',name:'奶油火箭便',tag:'小油油拿铁＋西梅汁：传说级喷射',body:'#7d4b8e',accent:'#f3d8a5',speed:1.18,weight:.92,bounce:.28,shape:'rocket',trail:'purple'},
    bouncy:{id:'bouncy',name:'香蕉弹弹便',tag:'香蕉＋酸奶：柔软高弹，落地还能蹦',body:'#e8b83d',accent:'#fff1a8',speed:.98,weight:.82,bounce:.78,shape:'banana',trail:'stars'},
    heavy:{id:'heavy',name:'红薯装甲便',tag:'红薯＋玉米：又大又沉，不怕风吹',body:'#804728',accent:'#f0c735',speed:.86,weight:1.35,bounce:.16,shape:'chunky',trail:'chunks'},
    fire:{id:'fire',name:'冰火爆破便',tag:'火锅＋汽水：碰到障碍会炸开',body:'#df4737',accent:'#ffbe3c',speed:1.06,weight:1.02,bounce:.3,shape:'fire',trail:'flame'},
    gas:{id:'gas',name:'气泡漂浮便',tag:'酸奶＋汽水：轻盈滞空，适合高处马桶',body:'#74a94f',accent:'#d9ef9d',speed:.92,weight:.62,bounce:.55,shape:'bubble',trail:'bubbles'},
    smooth:{id:'smooth',name:'黄金顺滑便',tag:'香蕉＋小油油拿铁：丝滑又稳定',body:'#cf9b2f',accent:'#fff0a5',speed:1.08,weight:.94,bounce:.42,shape:'smooth',trail:'sparkle'},
    plum:{id:'plum',name:'紫色瀑布便',tag:'西梅汁＋酸奶：分身喷射，速度极快',body:'#6f3e86',accent:'#c69ae0',speed:1.23,weight:.73,bounce:.48,shape:'drops',trail:'drops'},
    meteor:{id:'meteor',name:'火焰陨石便',tag:'火锅＋红薯：巨型火球，一路横冲直撞',body:'#6f3425',accent:'#ff713d',speed:.96,weight:1.45,bounce:.12,shape:'meteor',trail:'flame'},
    pop:{id:'pop',name:'玉米爆米便',tag:'玉米＋汽水：飞行中会不断爆出小颗粒',body:'#99703b',accent:'#ffe276',speed:1.02,weight:.9,bounce:.62,shape:'popcorn',trail:'popcorn'}
  };

  const recipeMap = {
    'latte|prune':'rocket','banana|yogurt':'bouncy','corn|yam':'heavy','hotpot|soda':'fire',
    'soda|yogurt':'gas','banana|latte':'smooth','prune|yogurt':'plum','hotpot|yam':'meteor','corn|soda':'pop'
  };

  const levels = [
    {name:'新手蹲坑',tip:'马桶又大又近，随便试试',scene:'bath',toilet:{x:286,y:374,w:78,h:94},gravity:.18,wind:0,angle:40,angleMin:31,angleMax:49,guide:true},
    {name:'洗手台马桶',tip:'抬高一点点，仍然很宽容',scene:'bath2',toilet:{x:292,y:315,w:76,h:92},gravity:.175,wind:0,angle:48,angleMin:39,angleMax:57,guide:true},
    {name:'低空云端马桶',tip:'看见轨迹变绿再松手',scene:'sky',toilet:{x:288,y:255,w:82,h:92},gravity:.16,wind:.004,angle:57,angleMin:47,angleMax:67,guide:true},
    {name:'左右横跳马桶',tip:'等马桶移动到轨迹落点',scene:'train',toilet:{x:275,y:300,w:74,h:88},gravity:.17,wind:0,angle:50,angleMin:40,angleMax:62,move:{axis:'x',amp:38,speed:.018},guide:true},
    {name:'屋顶强风马桶',tip:'指定配方能顶住强风',scene:'roof',toilet:{x:292,y:215,w:72,h:88},gravity:.155,wind:.026,angle:61,angleMin:52,angleMax:71,required:'heavy',requiredFood:'烤红薯＋玉米',guide:true},
    {name:'纸巾封锁线',tip:'指定配方能炸开纸巾墙',scene:'paper',toilet:{x:300,y:285,w:70,h:86},gravity:.165,wind:-.008,angle:57,angleMin:47,angleMax:68,required:'fire',requiredFood:'麻辣火锅＋冰汽水',obstacles:[{x:208,y:330,w:22,h:130,type:'paper'}],guide:true},
    {name:'飞机颠簸厕所',tip:'指定配方速度快，方便追移动马桶',scene:'plane',toilet:{x:294,y:265,w:70,h:86},gravity:.16,wind:.014,angle:58,angleMin:47,angleMax:69,required:'rocket',requiredFood:'小油油拿铁＋西梅汁',move:{axis:'y',amp:35,speed:.024},guide:true},
    {name:'太空失重马桶',tip:'指定配方能用气泡微调滞空',scene:'space',toilet:{x:285,y:170,w:76,h:90},gravity:.085,wind:-.006,angle:56,angleMin:44,angleMax:68,required:'gas',requiredFood:'酸奶＋冰汽水',move:{axis:'x',amp:42,speed:.012},guide:true}
  ];


  const mascotPhrases = [
    '冲呀冲呀！', '来个漂亮的~', '这次一定进！', '轻轻一发就好~',
    '快把它送进去！', '瞄准啦宝！', '别慌，稳住！', '发射发射！'
  ];
  const resultQuotes = [
    '鸡汤：今天能进坑，明天也能进步。',
    '鸡汤：慢一点没关系，进步本来就需要一点点蓄力。',
    '鸡汤：就算角度偏了，你也还是很可爱。',
    '鸡汤：先把这一关过了，再把生活那一关也过了。',
    '毒药：别急着骄傲，下一关还等着教育你。',
    '毒药：恭喜通关，但你的手法还有很大提升空间。',
    '毒药：这次是运气，下次未必。',
    '毒药：你以为自己很准？马桶只是今天心情好。'
  ];
  function pick(arr){return arr[Math.floor(Math.random()*arr.length)]}

  const state = {
    screen:'menu', level:0, unlocked:1, stars:Array(levels.length).fill(0), selected:[], type:types.normal,
    discovered:new Set(['normal']), sound:true, charging:false, chargeStart:0, power:0, launched:false,
    projectile:null, particles:[], attempts:0, time:0, toiletOffset:0, previewHit:false, tutorial:true, angle:40, angleDir:1, angleLocked:false, failureFx:null, buttKick:0, launchBurst:0, mascotLine:'', paused:false, sessionActive:false, sessionStartAt:0, totalScore:0
  };

  try {
    const save = JSON.parse(localStorage.getItem('panpan_game_la-le-tuo-da-de_save') || '{}');
    if (save.unlocked) state.unlocked=Math.max(1,Math.min(levels.length,save.unlocked));
    if (Array.isArray(save.stars)) state.stars=save.stars.slice(0,levels.length).concat(Array(levels.length).fill(0)).slice(0,levels.length);
    if (Array.isArray(save.discovered)) state.discovered=new Set(save.discovered);
  } catch(e) {}

  function saveGame(){
    try{localStorage.setItem('panpan_game_la-le-tuo-da-de_save',JSON.stringify({unlocked:state.unlocked,stars:state.stars,discovered:[...state.discovered]}));}catch(e){}
  }

  const audio = {
    ctx:null, musicTimer:null, note:0, chargeTimer:null,
    ensure(){
      const AudioCtor=window.AudioContext||window.webkitAudioContext;
      if(!AudioCtor){
        if(!this.unsupportedReported){
          this.unsupportedReported=true;
          window.PanPanGame?.error({code:'AUDIO_UNSUPPORTED',message:'当前浏览器不支持 Web Audio API',fatal:false});
        }
        state.sound=false; $('#soundBtn').textContent='🔇'; return;
      }
      if(!this.ctx) this.ctx=new AudioCtor();
      if(this.ctx.state==='suspended') this.ctx.resume().catch(()=>{});
      if(state.sound && !this.musicTimer) this.startMusic();
    },
    tone(freq,dur=.1,type='sine',vol=.04,when=0){
      if(!state.sound||!this.ctx)return;
      const t=this.ctx.currentTime+when,o=this.ctx.createOscillator(),g=this.ctx.createGain();
      o.type=type;o.frequency.setValueAtTime(freq,t);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
      o.connect(g);g.connect(this.ctx.destination);o.start(t);o.stop(t+dur+.02);
    },
    noise(dur=.12,vol=.025){
      if(!state.sound||!this.ctx)return;
      const len=Math.floor(this.ctx.sampleRate*dur),buf=this.ctx.createBuffer(1,len,this.ctx.sampleRate),data=buf.getChannelData(0);
      for(let i=0;i<len;i++)data[i]=(Math.random()*2-1)*(1-i/len);
      const src=this.ctx.createBufferSource(),g=this.ctx.createGain();src.buffer=buf;g.gain.value=vol;src.connect(g);g.connect(this.ctx.destination);src.start();
    },
    click(){this.tone(520,.06,'square',.025)},
    mix(){[523,659,784,1047].forEach((n,i)=>this.tone(n,.14,'triangle',.045,i*.07))},
    startCharge(){
      this.stopCharge(); let f=300;
      this.chargeTimer=setInterval(()=>{this.tone(f,.06,'square',.018);f=Math.min(850,f+45)},170);
    },
    stopCharge(){if(this.chargeTimer){clearInterval(this.chargeTimer);this.chargeTimer=null}},
    launch(type){this.noise(.16,.035);const base=type.id==='heavy'?150:type.id==='rocket'?520:360;this.tone(base,.24,'sawtooth',.045);this.tone(base*1.8,.14,'triangle',.025,.03)},
    hit(){this.noise(.22,.05);[392,523,659,784].forEach((n,i)=>this.tone(n,.2,'triangle',.05,i*.08))},
    fail(){this.tone(180,.32,'sawtooth',.04);this.tone(130,.34,'square',.025,.12)},
    startMusic(){
      if(!this.ctx||this.musicTimer)return;
      const melody=[523,659,784,659,587,698,880,698,523,659,784,1047,880,784,659,587];
      this.musicTimer=setInterval(()=>{
        if(!state.sound||!this.ctx)return;
        const n=melody[this.note%melody.length];
        this.tone(n,.18,'triangle',.018);if(this.note%4===0)this.tone(n/2,.22,'sine',.014);
        if(this.note%2===0)this.noise(.035,.006);
        this.note++;
      },235);
    },
    stopMusic(){if(this.musicTimer){clearInterval(this.musicTimer);this.musicTimer=null}this.stopCharge()}
  };


  function getScore(){
    return state.stars.reduce((sum,n)=>sum+n*100,0) + state.discovered.size*25;
  }
  function beginSession(){
    if(state.sessionActive) return;
    state.sessionActive=true;
    state.sessionStartAt=Date.now();
    state.totalScore=getScore();
    window.PanPanGame?.start({mode:'normal'});
  }
  function endSession(result){
    if(!state.sessionActive) return;
    const durationSeconds=Math.max(1,Math.round((Date.now()-state.sessionStartAt)/1000));
    window.PanPanGame?.end({score:getScore(),durationSeconds,result});
    state.sessionActive=false;
  }
  function setMuted(muted){
    state.sound=!muted;
    $('#soundBtn').textContent=state.sound?'🔊':'🔇';
    if(!state.sound) audio.stopMusic();
    else if(audio.ctx && !state.paused) audio.startMusic();
  }
  function pauseGame(reason){
    if(state.paused || state.screen!=='#gameScreen') return;
    state.paused=true;
    audio.stopMusic();
    $('#pauseOverlay').classList.add('show');
    window.PanPanGame?.pause({reason:reason||'unknown'});
  }
  function resumeGame(reason){
    if(!state.paused) return;
    state.paused=false;
    $('#pauseOverlay').classList.remove('show');
    if(state.sound && audio.ctx) audio.startMusic();
    last=performance.now();
    window.PanPanGame?.resume({reason:reason||'unknown'});
  }

  function showScreen(id){
    document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
    $(id).classList.add('active'); state.screen=id;
  }

  function buildLevels(){
    const grid=$('#levelGrid');grid.innerHTML='';
    levels.forEach((lv,i)=>{
      const b=document.createElement('button');b.className='level-btn'+(i>=state.unlocked?' locked':'')+(i===state.level?' current':'');
      b.innerHTML=`${i+1}${lv.required?'<small style="display:block;font-size:9px">🧪指定</small>':''}<span class="stars">${state.stars[i]?'★'.repeat(state.stars[i])+'☆'.repeat(3-state.stars[i]):'☆☆☆'}</span>`;
      b.addEventListener('click',()=>{audio.ensure();audio.click();if(i<state.unlocked){state.level=i;openLab();}});grid.appendChild(b);
    });
    $('#progressText').textContent=`${state.unlocked} / ${levels.length}`;
  }

  function buildFoods(){
    const grid=$('#foodGrid');grid.innerHTML='';
    foods.forEach(f=>{
      const b=document.createElement('button');b.className='food-card';b.dataset.id=f.id;
      b.innerHTML=`<span class="food-icon">${f.icon}</span><span><div class="food-name">${f.name}</div><div class="food-desc">${f.desc}</div></span>`;
      b.addEventListener('click',()=>selectFood(f.id));grid.appendChild(b);
    });
  }

  function selectFood(id){
    audio.ensure();audio.click();
    const idx=state.selected.indexOf(id);
    if(idx>=0)state.selected.splice(idx,1);
    else {if(state.selected.length>=2)state.selected.shift();state.selected.push(id)}
    updateLab();
    if(state.selected.length===2){audio.mix();const key=[...state.selected].sort().join('|');const type=types[recipeMap[key]||'normal'];state.discovered.add(type.id);saveGame();}
  }

  function updateLab(){
    document.querySelectorAll('.food-card').forEach(b=>b.classList.toggle('selected',state.selected.includes(b.dataset.id)));
    [$('#slot1'),$('#slot2')].forEach((slot,i)=>{
      const f=foods.find(x=>x.id===state.selected[i]);slot.innerHTML=f?`<span class="emoji">${f.icon}</span><span>${f.name}</span>`:`<span class="emoji">?</span><span>选第${i+1}种</span>`;
    });
    const result=$('#recipeResult');
    if(state.selected.length===2){
      const key=[...state.selected].sort().join('|');state.type=types[recipeMap[key]||'normal'];result.classList.add('show');
      $('#resultName').textContent=state.type.name;$('#resultTag').textContent=state.type.tag;
      $('#statSpeed').textContent=starsValue(state.type.speed,.8,1.25);$('#statWeight').textContent=starsValue(state.type.weight,.6,1.45);$('#statBounce').textContent=starsValue(state.type.bounce,.1,.8);
      drawPoop($('#previewCanvas').getContext('2d'),38,41,state.type,1.15,0,0);
    } else result.classList.remove('show');
    updateRequirement();
  }
  function starsValue(v,min,max){const n=Math.max(1,Math.min(5,Math.round(1+(v-min)/(max-min)*4)));return '★'.repeat(n)+'☆'.repeat(5-n)}

  function requirementOK(){const req=levels[state.level].required;return !req||state.type.id===req}
  function updateRequirement(){
    const box=$('#levelRequirement'),lv=levels[state.level];
    if(!lv.required){box.className='requirement';box.textContent='';$('#useRecipe').disabled=false;$('#useRecipe').textContent='带它去闯关';return}
    const need=types[lv.required],ok=state.selected.length===2&&state.type.id===lv.required;
    box.className='requirement show '+(ok?'ok':'bad');
    box.innerHTML=ok?`✅ 本关配方正确：<b>${need.name}</b>`:`第${state.level+1}关指定：<b>${need.name}</b><br>配方提示：${lv.requiredFood}<br><span style='opacity:.75'>先在炼丹房配好，再来拉这个大的</span>`;
    $('#useRecipe').disabled=!ok;$('#useRecipe').style.opacity=ok?'1':'.48';$('#useRecipe').textContent=ok?'使用指定配方闯关':'请先合成指定配方';
  }

  function openLab(){state.selected=[];state.type=types.normal;updateLab();updateRequirement();showScreen('#labScreen')}

  function startLevel(){
    const lv=levels[state.level];
    if(lv.required&&state.type.id!==lv.required){toast(`本关需要${types[lv.required].name}`);openLab();return}
    beginSession();audio.ensure();state.attempts=0;state.tutorial=(state.level>0&&state.level<3);state.mascotLine=pick(mascotPhrases);showScreen('#gameScreen');
    state.angle=lv.angle;state.angleDir=1;state.angleLocked=false;updateAngleUI();
    $('#levelTitle').innerHTML=`第${state.level+1}关<small>${lv.name}${lv.required?' · 指定'+types[lv.required].name:''}</small>`;
    $('#miniRecipeName').textContent=state.type.name.replace('便便','便');drawMini();resetShot(true);requestAnimationFrame(loop);
  }

  function resetShot(first=false){
    (levels[state.level].obstacles||[]).forEach(o=>o.broken=false);
    state.charging=false;audio.stopCharge();state.power=0;state.launched=false;state.projectile=null;state.particles=[];state.failureFx=null;state.time=0;state.previewHit=false;state.angleLocked=false;state.buttKick=0;state.launchBurst=0;
    $('#powerFill').style.width='0%';$('#powerText').textContent='0%';$('#holdBtn').classList.remove('charging');$('#holdBtn').textContent='按住蓄力 · 松手发射';state.mascotLine=pick(mascotPhrases);
    $('#tutorial').style.display=state.tutorial?'block':'none';updatePerfectZone();if(!first)toast('重新对准，再来一次');
  }

  function currentToilet(){
    const lv=levels[state.level],t={...lv.toilet};
    if(lv.move){const d=Math.sin(state.time*lv.move.speed)*lv.move.amp;if(lv.move.axis==='x')t.x+=d;else t.y+=d}
    return t;
  }

  function chargeStart(e){
    if(state.launched||state.charging||state.failureFx)return;e.preventDefault();audio.ensure();state.charging=true;state.angleLocked=true;state.chargeStart=performance.now();state.tutorial=false;$('#tutorial').style.display='none';$('#holdBtn').classList.add('charging');$('#holdBtn').textContent='继续按住… 松手才发射';audio.startCharge();
    if(e.pointerId!==undefined)$('#holdBtn').setPointerCapture?.(e.pointerId);
  }
  function chargeEnd(e){
    if(!state.charging)return;e?.preventDefault();state.charging=false;audio.stopCharge();$('#holdBtn').classList.remove('charging');launch();
  }

  function updatePerfectZone(){
    const zone=document.querySelector('.perfect-zone');
    const lv=levels[state.level];
    if(lv.move){zone.style.display='none';return}
    const angle=state.angle,hits=[];
    for(let p=12;p<=100;p++)if(simulate(p,angle).hit)hits.push(p);
    if(!hits.length){zone.style.display='none';return}
    zone.style.display='block';zone.style.left=Math.min(...hits)+'%';zone.style.width=Math.max(4,Math.max(...hits)-Math.min(...hits)+1)+'%';
  }

  function launch(){
    if(state.launched)return;state.launched=true;state.attempts++;
    const angle=state.angle*Math.PI/180,p=Math.max(12,state.power),type=state.type;
    const speed=p*.142*type.speed;
    state.projectile={x:START_X,y:START_Y,vx:Math.cos(angle)*speed,vy:-Math.sin(angle)*speed,r:15*(.82+type.weight*.22),rot:0,life:0,hitObstacle:false};
    state.buttKick=1; state.launchBurst=1; spawnButtSpray(Math.cos(angle),-Math.sin(angle));
    audio.launch(type);$('#holdBtn').textContent='飞行中…';
  }

  function simulate(power,angleDeg,draw=false){
    const lv=levels[state.level],type=state.type,t=currentToilet();let x=START_X,y=START_Y;
    const a=angleDeg*Math.PI/180,s=power*.142*type.speed;let vx=Math.cos(a)*s,vy=-Math.sin(a)*s;
    let hit=false,pts=[];
    for(let i=0;i<210;i++){
      vx+=lv.wind/type.weight;vy+=lv.gravity*type.weight;x+=vx;y+=vy;if(i%7===0)pts.push({x,y});
      if(x>t.x+5&&x<t.x+t.w-5&&y>t.y+9&&y<t.y+47&&vy>0){hit=true;break}
      if(x>W+30||y>H+30||y<-50)break;
    }
    return {hit,pts};
  }

  function update(dt){
    state.time+=dt;
    state.buttKick*=0.9; state.launchBurst*=0.88;
    const lv=levels[state.level];
    if(!state.angleLocked&&!state.launched&&!state.failureFx){
      state.angle+=state.angleDir*.28*dt;
      if(state.angle>=lv.angleMax){state.angle=lv.angleMax;state.angleDir=-1}
      if(state.angle<=lv.angleMin){state.angle=lv.angleMin;state.angleDir=1}
      updateAngleUI();
    }
    if(state.charging){
      state.power=Math.min(100,12+(performance.now()-state.chargeStart)/2500*88);$('#powerFill').style.width=state.power+'%';$('#powerText').textContent=Math.round(state.power)+'%';
    }
    updateParticles(dt);
    if(state.failureFx){
      if(performance.now()-state.failureFx.start>state.failureFx.duration){state.failureFx=null;resetShot()}
      return;
    }
    const p=state.projectile;if(!p)return;
    p.life+=dt;p.vx+=lv.wind/typeSafeWeight();p.vy+=lv.gravity*state.type.weight;p.x+=p.vx;p.y+=p.vy;p.rot+=p.vx*.025;
    spawnTrail(p);
    for(const ob of (lv.obstacles||[])){
      if(circleRect(p.x,p.y,p.r,ob)){
        if(state.type.id==='fire'||state.type.id==='meteor'){p.hitObstacle=true;ob.broken=true;burst(p.x,p.y,'#ff843d',18);audio.noise(.15,.04)}
        else if(!ob.broken){p.vx*=-.25;p.vy*=-.45;p.x=ob.x-p.r;burst(p.x,p.y,'#eee6dc',8)}
      }
    }
    const t=currentToilet();
    if(p.x>t.x+3&&p.x<t.x+t.w-3&&p.y>t.y+6&&p.y<t.y+51&&p.vy>-.3){win();return}
    if(p.y>460){
      if(state.type.bounce>.55&&p.life<180&&Math.abs(p.vy)>1.4){p.y=460;p.vy=-Math.abs(p.vy)*state.type.bounce;p.vx*=.82;burst(p.x,p.y,'#e6c873',7)}
      else fail('ground','落地没进坑，开启弹弹派对');
    } else if(p.y<-80) fail('sky','飞上云端，变成了欢乐粑粑雨');
    else if(p.x>W+35) fail('overshoot','冲过头了，变成一颗便便流星');
    else if(p.x<-35) fail('backward','方向反了，便便又绕回来了');
    else if(p.life>560) fail('lost','飞太久了，被云朵打包退回');
  }
  function updateParticles(dt){
    state.particles.forEach(q=>{
      q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=(q.g||0)*dt;q.life-=dt;q.r*=q.shrink||.994;q.rot=(q.rot||0)+(q.vr||0)*dt;
      if(q.kind==='rain'&&q.y>H+20){q.y=-20-Math.random()*120;q.x=Math.random()*W}
    });
    state.particles=state.particles.filter(q=>q.life>0);
  }
  function typeSafeWeight(){return Math.max(.55,state.type.weight)}
  function circleRect(cx,cy,r,o){return cx+r>o.x&&cx-r<o.x+o.w&&cy+r>o.y&&cy-r<o.y+o.h}

  function win(){
    const p=state.projectile;if(!p)return;burst(p.x,p.y,state.type.body,30);state.projectile=null;audio.hit();
    const stars=state.attempts===1?3:state.attempts<=3?2:1;state.stars[state.level]=Math.max(state.stars[state.level],stars);state.unlocked=Math.max(state.unlocked,Math.min(levels.length,state.level+2));saveGame();
    $('#resultIcon').textContent=stars===3?'🏆':'🎉';$('#resultTitle').textContent=stars===3?'完美入坑！':'成功通关！';$('#resultStars').innerHTML='★'.repeat(stars)+`<span class="muted">${'★'.repeat(3-stars)}</span>`;
    state.totalScore=getScore();window.PanPanGame?.levelComplete({level:state.level+1,score:state.totalScore});window.PanPanGame?.score({score:state.totalScore});if(state.level===levels.length-1)endSession('completed');
    $('#resultText').textContent=`${state.type.name}精准落入「${levels[state.level].name}」。本关尝试 ${state.attempts} 次。`;$('#resultQuote').textContent=pick(resultQuotes);
    $('#nextBtn').style.display=state.level<levels.length-1?'block':'none';$('#resultModal').classList.add('show');buildLevels();
  }
  function fail(kind,msg){
    if(!state.projectile)return;const p={...state.projectile};state.projectile=null;audio.fail();
    state.failureFx={kind,msg,start:performance.now(),duration:kind==='sky'?2200:1700,origin:p};
    $('#holdBtn').textContent='趣味事故中…';spawnFailureFx(kind,p);toast(msg);
  }

  function spawnFailureFx(kind,p){
    if(kind==='sky'){
      for(let i=0;i<26;i++)state.particles.push({kind:'rain',x:15+Math.random()*(W-30),y:-20-Math.random()*300,vx:(Math.random()-.5)*.45,vy:1.6+Math.random()*2.6,r:5+Math.random()*5,life:190,g:.013,rot:Math.random()*6.28,vr:(Math.random()-.5)*.12,color:['#795033','#cf9b2f','#7d4b8e','#df4737'][i%4]});
      for(let i=0;i<22;i++)state.particles.push({kind:'star',x:Math.random()*W,y:18+Math.random()*190,vx:(Math.random()-.5)*.55,vy:.25+Math.random()*1.1,r:3+Math.random()*3.5,life:135,g:.002,rot:0,vr:.1,color:i%2?'#ffe176':'#9ae9ff'});
      for(let i=0;i<24;i++)state.particles.push({kind:'confetti',x:Math.random()*W,y:-10-Math.random()*120,vx:(Math.random()-.5)*1.4,vy:1.0+Math.random()*1.8,r:5+Math.random()*3,life:130,g:.025,rot:Math.random()*6.28,vr:(Math.random()-.5)*.24,color:['#ff8db1','#72d77c','#7ec9ff','#ffd869'][i%4]});
    } else if(kind==='ground'){
      for(let i=0;i<16;i++)state.particles.push({kind:'mini',x:p.x+(Math.random()-.5)*34,y:476,vx:(Math.random()-.5)*3.4,vy:-3.0-Math.random()*3.8,r:5+Math.random()*5,life:88,g:.11,rot:0,vr:(Math.random()-.5)*.2,color:state.type.body});
      for(let i=0;i<20;i++)state.particles.push({kind:'star',x:p.x,y:470,vx:(Math.random()-.5)*4.2,vy:-2-Math.random()*4.2,r:3+Math.random()*3.2,life:72,g:.09,rot:0,vr:.18,color:'#ffd75a'});
      for(let i=0;i<18;i++)state.particles.push({kind:'confetti',x:p.x,y:468,vx:(Math.random()-.5)*5.2,vy:-2.1-Math.random()*3.6,r:5,life:76,g:.08,rot:Math.random()*6.28,vr:(Math.random()-.5)*.22,color:['#ff8db1','#72d77c','#7ec9ff','#ffd869'][i%4]});
    } else if(kind==='overshoot'){
      for(let i=0;i<26;i++)state.particles.push({kind:'star',x:W-12-i*4.2,y:122+i*4,vx:-1.7-Math.random()*1.2,vy:(Math.random()-.5)*1.1,r:2+Math.random()*3.4,life:95,g:0,rot:0,vr:.15,color:i%2?'#8be0ff':'#ffe176'});
      for(let i=0;i<18;i++)state.particles.push({kind:'confetti',x:W-16,y:120+i*2,vx:-1.4-Math.random()*2,vy:(Math.random()-.5)*1.2,r:5,life:85,g:0,rot:Math.random()*6.28,vr:(Math.random()-.5)*.25,color:['#ff8db1','#72d77c','#7ec9ff','#ffd869'][i%4]});
      state.particles.push({kind:'mini',x:W-14,y:122,vx:-2.7,vy:.25,r:11,life:110,g:0,rot:0,vr:.16,color:state.type.body});
    } else {
      burst(p.x,p.y,state.type.body,18);
      for(let i=0;i<18;i++)state.particles.push({kind:'star',x:p.x,y:p.y,vx:(Math.random()-.5)*3.6,vy:(Math.random()-.5)*3.6,r:3+Math.random()*2,life:62,g:.03,rot:0,vr:.2,color:i%2?'#ffe176':'#9ae9ff'});
      for(let i=0;i<10;i++)state.particles.push({kind:'confetti',x:p.x,y:p.y,vx:(Math.random()-.5)*4.5,vy:(Math.random()-.5)*3.4,r:5,life:64,g:.03,rot:Math.random()*6.28,vr:(Math.random()-.5)*.25,color:['#ff8db1','#72d77c','#7ec9ff','#ffd869'][i%4]});
    }
  }


  function burst(x,y,color,count){for(let i=0;i<count;i++){const a=Math.random()*Math.PI*2,s=.6+Math.random()*3;state.particles.push({kind:'dot',x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-1,r:2+Math.random()*4,color,life:30+Math.random()*35,g:.045,shrink:.992})}}

  function spawnButtSpray(dx,dy){
    for(let i=0;i<18;i++){
      const spread=(Math.random()-.5)*1.15;
      const speed=1.5+Math.random()*2.8;
      const c=i%3===0?state.type.accent:state.type.body;
      state.particles.push({
        kind:i%4===0?'confetti':'mini',
        x:START_X-3+Math.random()*6,
        y:START_Y+2+Math.random()*8,
        vx:dx*speed + spread,
        vy:dy*speed + spread*0.65,
        r:4+Math.random()*4,
        life:45+Math.random()*28,
        g:.04,
        rot:Math.random()*6.28,
        vr:(Math.random()-.5)*.24,
        color:c
      });
    }
    for(let i=0;i<8;i++){
      state.particles.push({
        kind:'star',
        x:START_X, y:START_Y,
        vx:dx*(1.3+Math.random()*1.8)+(Math.random()-.5)*1.2,
        vy:dy*(1.3+Math.random()*1.8)+(Math.random()-.5)*1.2,
        r:2+Math.random()*3,
        life:34+Math.random()*18,
        g:.035, rot:0, vr:.16,
        color:i%2?'#ffe176':'#9ae9ff'
      });
    }
  }

  function spawnTrail(p){
    if(Math.random()>.65)return;const t=state.type;let color=t.accent;
    const count=t.shape==='drops'?2:1;
    for(let i=0;i<count;i++)state.particles.push({x:p.x-p.vx*1.5+(Math.random()-.5)*7,y:p.y-p.vy*1.5+(Math.random()-.5)*7,vx:-p.vx*.06+(Math.random()-.5)*.5,vy:-p.vy*.06+(Math.random()-.5)*.5,r:t.trail==='bubbles'?3+Math.random()*4:2+Math.random()*3,color,life:18+Math.random()*14,g:t.trail==='bubbles'?-.025:.025});
  }

  function draw(){
    const lv=levels[state.level];drawScene(lv);const t=currentToilet();drawObstacles(lv);drawLauncher();
    const previewPower=state.charging?state.power:58;const sim=simulate(previewPower,state.angle);state.previewHit=sim.hit;drawTrajectory(sim.pts,sim.hit,state.charging||(!state.launched&&!state.failureFx));
    drawToilet(t,sim.hit&&state.charging);drawWind(lv);
    state.particles.forEach(q=>drawParticle(q));ctx.globalAlpha=1;
    if(state.failureFx)drawFailureCaption(state.failureFx);
    if(state.projectile)drawPoop(ctx,state.projectile.x,state.projectile.y,state.type,state.projectile.r/15,state.projectile.rot,state.time);
  }


  function drawParticle(q){
    ctx.save();ctx.globalAlpha=Math.min(1,Math.max(0,q.life/35));ctx.translate(q.x,q.y);ctx.rotate(q.rot||0);
    if(q.kind==='rain'||q.kind==='mini'){
      const temp={...types.normal,body:q.color||types.normal.body,accent:'#fff2a6'};drawPoop(ctx,0,0,temp,Math.max(.26,q.r/16),0,state.time);
    } else if(q.kind==='star'){
      ctx.fillStyle=q.color;ctx.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?q.r*.45:q.r;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();
    } else if(q.kind==='confetti'){
      ctx.fillStyle=q.color;ctx.fillRect(-q.r*.9,-q.r*.45,q.r*1.8,q.r*.9);
      ctx.strokeStyle='rgba(74,51,38,.25)';ctx.lineWidth=1;ctx.strokeRect(-q.r*.9,-q.r*.45,q.r*1.8,q.r*.9);
    } else {
      ctx.fillStyle=q.color;ctx.beginPath();ctx.arc(0,0,q.r,0,Math.PI*2);ctx.fill();
    }
    ctx.restore();
  }


  function drawFailureCaption(fx){
    const elapsed=performance.now()-fx.start,fade=Math.min(1,elapsed/180, (fx.duration-elapsed)/250);
    const title=fx.kind==='sky'?'☁️ 天空开启粑粑雨':fx.kind==='ground'?'🎉 地面弹弹派对':fx.kind==='overshoot'?'☄️ 便便流星出逃':fx.kind==='backward'?'↩️ 回旋便便返场':'📦 云朵退件';
    const subtitle=fx.kind==='sky'?'冲太高啦，云朵把它拆成了小礼花':fx.kind==='ground'?'落地弹一弹，再来一发更大的':fx.kind==='overshoot'?'飞过头啦，下一发记得收一点力':fx.kind==='backward'?'角度有点刁钻，屁股都扭回来了':'马桶拒收，已原路退回';
    ctx.save();ctx.globalAlpha=.95*fade;
    ctx.fillStyle='rgba(255,250,239,.96)';ctx.strokeStyle='#634735';ctx.lineWidth=3;
    ctx.beginPath();ctx.roundRect(60,20,W-120,66,16);ctx.fill();ctx.stroke();
    ctx.fillStyle='#4a3326';ctx.font='bold 17px -apple-system,BlinkMacSystemFont,sans-serif';ctx.textAlign='center';ctx.fillText(title,W/2,44);
    ctx.font='12px -apple-system,BlinkMacSystemFont,sans-serif';ctx.fillStyle='rgba(74,51,38,.74)';ctx.fillText(subtitle,W/2,66);
    ctx.restore();
  }

  function drawScene(lv){
    const g=ctx.createLinearGradient(0,0,0,H);
    if(lv.scene==='space'){g.addColorStop(0,'#1b173a');g.addColorStop(1,'#40346e')}else if(['sky','roof','paper'].includes(lv.scene)){g.addColorStop(0,'#82d2ef');g.addColorStop(1,'#e9f8ff')}else if(lv.scene==='train'){g.addColorStop(0,'#d9eef0');g.addColorStop(1,'#9bbfc4')}else if(lv.scene==='plane'){g.addColorStop(0,'#d6edf5');g.addColorStop(1,'#f6f0dc')}else{g.addColorStop(0,'#b9e8f2');g.addColorStop(1,'#f3e4c6')}
    ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
    if(lv.scene==='space'){
      for(let i=0;i<32;i++){const x=(i*83)%W,y=(i*47)%330;ctx.fillStyle=i%5===0?'#ffe8a3':'#fff';ctx.globalAlpha=.5+.4*Math.sin(state.time*.02+i);ctx.fillRect(x,y,2,2)}ctx.globalAlpha=1;
      ctx.fillStyle='#6e5b8e';ctx.beginPath();ctx.arc(30,50,42,0,Math.PI*2);ctx.fill();ctx.fillStyle='#8a75a8';ctx.beginPath();ctx.arc(18,38,9,0,Math.PI*2);ctx.fill();
    } else if(['sky','roof','paper'].includes(lv.scene)){
      drawCloud(55,92,1);drawCloud(265,70,.7);drawCloud(155,210,.55);
      if(lv.scene==='roof'){ctx.fillStyle='#b65d4b';ctx.beginPath();ctx.moveTo(0,418);ctx.lineTo(210,310);ctx.lineTo(390,405);ctx.lineTo(390,500);ctx.lineTo(0,500);ctx.fill();ctx.strokeStyle='#773d33';ctx.lineWidth=5;ctx.stroke()}
      else {ctx.fillStyle='#8bc66e';ctx.fillRect(0,461,W,39)}
    } else if(lv.scene==='train'){
      ctx.fillStyle='#eef8f7';ctx.fillRect(17,55,356,348);ctx.strokeStyle='#68818b';ctx.lineWidth=8;ctx.strokeRect(17,55,356,348);
      for(let x=45;x<350;x+=92){ctx.fillStyle='#8dd5ed';ctx.fillRect(x,92,68,92);ctx.fillStyle='#74b46b';ctx.fillRect(x,160,68,24)}
      ctx.fillStyle='#7c8990';ctx.fillRect(0,427,W,73);ctx.strokeStyle='#d7d0ad';ctx.lineWidth=5;for(let x=-30+(state.time*2)%60;x<W;x+=60){ctx.beginPath();ctx.moveTo(x,475);ctx.lineTo(x+30,430);ctx.stroke()}
    } else if(lv.scene==='plane'){
      ctx.fillStyle='#f5f1e8';ctx.fillRect(22,35,346,395);ctx.strokeStyle='#9eaeb5';ctx.lineWidth=7;ctx.strokeRect(22,35,346,395);ctx.fillStyle='#7ecae5';ctx.beginPath();ctx.ellipse(195,130,72,46,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(195,130,54,30,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#8ca3aa';ctx.fillRect(0,430,W,70);
    } else {
      ctx.fillStyle='#f3e4ca';ctx.fillRect(0,0,W,452);ctx.strokeStyle='#d2b995';ctx.lineWidth=1;for(let x=0;x<W;x+=48){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,452);ctx.stroke()}for(let y=0;y<452;y+=48){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
      ctx.fillStyle='#88c7d5';ctx.fillRect(22,35,120,105);ctx.strokeStyle='#fff';ctx.lineWidth=8;ctx.strokeRect(22,35,120,105);ctx.fillStyle='#a67f58';ctx.fillRect(0,452,W,48);
      if(lv.scene==='bath2'){ctx.fillStyle='#d9ccc0';ctx.fillRect(232,390,158,18);ctx.fillRect(260,407,25,45)}
    }
  }
  function drawCloud(x,y,s){ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.fillStyle='rgba(255,255,255,.85)';ctx.beginPath();ctx.arc(0,15,23,0,Math.PI*2);ctx.arc(28,0,29,0,Math.PI*2);ctx.arc(60,15,23,0,Math.PI*2);ctx.fill();ctx.restore()}

  function updateAngleUI(){
    const lv=levels[state.level]||levels[0],span=Math.max(1,lv.angleMax-lv.angleMin),pct=(state.angle-lv.angleMin)/span*100;
    $('#angle').value=state.angle;$('#angleValue').textContent=Math.round(state.angle)+'°';$('#angleMarker').style.left=Math.max(0,Math.min(100,pct))+'%';
  }




  function drawFrontMascot(c,x,y,scale=1,t=0){
    const bounce=Math.sin(t*.12)*5;
    c.save();
    c.translate(x,y+bounce);
    c.scale(scale,scale);

    c.fillStyle='rgba(120,90,80,.12)';
    c.beginPath(); c.ellipse(0,42,38,10,0,0,Math.PI*2); c.fill();

    c.fillStyle='#ffd8cc';
    c.strokeStyle='#f5a78d';
    c.lineWidth=2.2;
    c.beginPath(); c.ellipse(0,0,48,40,0,0,Math.PI*2); c.fill(); c.stroke();

    c.strokeStyle='#f5a78d'; c.lineWidth=6;
    c.beginPath(); c.arc(0,-42,11,.2,Math.PI*1.45,true); c.stroke();

    c.fillStyle='rgba(255,120,145,.28)';
    c.beginPath(); c.ellipse(-23,7,10,6,0,0,Math.PI*2); c.ellipse(23,7,10,6,0,0,Math.PI*2); c.fill();

    c.fillStyle='#7b3e34';
    c.beginPath(); c.ellipse(-16,-2,6,8,0,0,Math.PI*2); c.ellipse(16,-2,6,8,0,0,Math.PI*2); c.fill();
    c.fillStyle='#fff';
    c.beginPath(); c.arc(-14,-5,2,0,Math.PI*2); c.arc(18,-5,2,0,Math.PI*2); c.fill();

    c.fillStyle='#ef6d73';
    c.beginPath(); c.ellipse(0,12,9,7,0,0,Math.PI); c.fill();
    c.strokeStyle='#d15f68'; c.lineWidth=1.4;
    c.beginPath(); c.arc(0,12,9,0,Math.PI); c.stroke();

    c.fillStyle='#a9d9f3';
    c.strokeStyle='#7fb8d7'; c.lineWidth=2;
    c.beginPath();
    c.moveTo(-35,24); c.quadraticCurveTo(0,16,35,24); c.lineTo(30,44); c.quadraticCurveTo(0,35,-30,44); c.closePath();
    c.fill(); c.stroke();

    c.fillStyle='rgba(255,255,255,.72)';
    [[-22,29],[-8,26],[7,30],[22,27],[-15,39],[0,37],[15,39]].forEach(p=>{c.beginPath(); c.arc(p[0],p[1],2.6,0,Math.PI*2); c.fill();});

    c.fillStyle='#f48fb4';
    c.strokeStyle='#de709a'; c.lineWidth=1.4;
    c.beginPath(); c.ellipse(0,26,10,7,0,0,Math.PI*2); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(-10,26); c.quadraticCurveTo(-18,18,-18,28); c.quadraticCurveTo(-18,34,-10,31); c.closePath(); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(10,26); c.quadraticCurveTo(18,18,18,28); c.quadraticCurveTo(18,34,10,31); c.closePath(); c.fill(); c.stroke();

    const legLift=Math.abs(Math.sin(t*.12))*2;
    c.fillStyle='#ffd8cc';
    c.strokeStyle='#f5a78d'; c.lineWidth=2;
    c.beginPath(); c.ellipse(-18,47-legLift,12,16,.08,0,Math.PI*2); c.fill(); c.stroke();
    c.beginPath(); c.ellipse(18,47+legLift,12,16,-.08,0,Math.PI*2); c.fill(); c.stroke();


    c.restore();
  }

  function drawBackMascot(c,x,y,scale=1,t=0,charge=0,kick=0){
    const jiggle=Math.sin(t*.22)*(charge>.02?.18:.05);
    const squashY=1-charge*.14-kick*.06;
    const squashX=1+charge*.10+kick*.06;
    c.save();
    c.translate(x,y-kick*6);
    c.rotate(-.08+jiggle);
    c.scale(scale*squashX,scale*squashY);

    c.fillStyle='rgba(120,90,80,.12)';
    c.beginPath(); c.ellipse(0,48,40,11,0,0,Math.PI*2); c.fill();

    c.fillStyle='#ffd8cc';
    c.strokeStyle='#f5a78d';
    c.lineWidth=2.2;
    c.beginPath(); c.ellipse(-16,0,28,34,0,0,Math.PI*2); c.fill(); c.stroke();
    c.beginPath(); c.ellipse(16,0,28,34,0,0,Math.PI*2); c.fill(); c.stroke();

    c.strokeStyle='#f5a78d'; c.lineWidth=6;
    c.beginPath(); c.arc(0,-42,11,.2,Math.PI*1.45,true); c.stroke();

    c.strokeStyle='#e8a08b'; c.lineWidth=2;
    c.beginPath(); c.moveTo(0,-12); c.quadraticCurveTo(-1,4,0,26); c.stroke();

    c.fillStyle='#d79a90';
    c.beginPath(); c.ellipse(0,8,5+charge*4+kick*2,4+charge*2.5+kick,0,0,Math.PI*2); c.fill();

    c.fillStyle='#a9d9f3';
    c.strokeStyle='#7fb8d7'; c.lineWidth=2;
    c.beginPath();
    c.moveTo(-40,18); c.quadraticCurveTo(0,8,40,18); c.lineTo(32,42); c.quadraticCurveTo(0,32,-32,42); c.closePath();
    c.fill(); c.stroke();

    c.fillStyle='rgba(255,255,255,.72)';
    [[-25,24],[-10,20],[8,25],[25,22],[-18,34],[-1,31],[17,34]].forEach(p=>{c.beginPath(); c.arc(p[0],p[1],2.6,0,Math.PI*2); c.fill();});

    c.fillStyle='#f48fb4';
    c.strokeStyle='#de709a'; c.lineWidth=1.4;
    c.beginPath(); c.ellipse(0,18,10,7,0,0,Math.PI*2); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(-10,18); c.quadraticCurveTo(-18,10,-18,20); c.quadraticCurveTo(-18,26,-10,23); c.closePath(); c.fill(); c.stroke();
    c.beginPath(); c.moveTo(10,18); c.quadraticCurveTo(18,10,18,20); c.quadraticCurveTo(18,26,10,23); c.closePath(); c.fill(); c.stroke();

    c.fillStyle='#ffd8cc';
    c.strokeStyle='#f5a78d'; c.lineWidth=2;
    c.beginPath(); c.ellipse(-16,49,12,18,.08,0,Math.PI*2); c.fill(); c.stroke();
    c.beginPath(); c.ellipse(16,49,12,18,-.08,0,Math.PI*2); c.fill(); c.stroke();

    if(charge>.02 || kick>.02){
      c.strokeStyle='rgba(74,51,38,.25)';
      c.lineWidth=1.5;
      [[-49,-6,-35,-2],[-47,16,-31,12],[48,-8,33,-4],[49,14,33,12]].forEach(s=>{
        c.beginPath();
        c.moveTo(s[0],s[1]);
        c.quadraticCurveTo((s[0]+s[2])/2 + Math.sin(t*.25)*2,(s[1]+s[3])/2,s[2],s[3]);
        c.stroke();
      });
    }

    c.restore();
  }


  function drawSpeechBubble(c,x,y,text){
    if(!text)return;
    c.save();
    c.font='bold 12px -apple-system,BlinkMacSystemFont,sans-serif';
    const padX=10, padY=8;
    const w=Math.min(126, c.measureText(text).width + padX*2);
    const h=32;
    c.translate(x,y);
    c.fillStyle='rgba(255,252,244,.98)';
    c.strokeStyle='#7a5947';
    c.lineWidth=2;
    c.beginPath();
    c.roundRect(-w/2, -h/2, w, h, 12);
    c.fill(); c.stroke();
    c.beginPath();
    c.moveTo(-8,h/2-1); c.lineTo(0,h/2+10); c.lineTo(8,h/2-1); c.closePath();
    c.fill(); c.stroke();
    c.fillStyle='#6a4d3f';
    c.textAlign='center';
    c.textBaseline='middle';
    c.fillText(text, 0, 1);
    c.restore();
  }

  function drawLauncher(){
    const a=state.angle*Math.PI/180;
    const kick=state.buttKick||0;
    const charge=state.charging ? Math.min(1,state.power/100) : 0;
    const showFront = !state.charging && !state.launched && !state.failureFx;

    ctx.strokeStyle='rgba(74,51,38,.78)';
    ctx.lineWidth=4;
    ctx.beginPath();
    ctx.moveTo(START_X,START_Y);
    ctx.lineTo(START_X+Math.cos(a)*42,START_Y-Math.sin(a)*42);
    ctx.stroke();

    if(state.charging || kick>0.03){
      ctx.save();
      const dots = state.charging ? 3 : 5;
      for(let i=0;i<dots;i++){
        const dist = 8 + i*7 + kick*10;
        const dx = Math.cos(a)*dist;
        const dy = -Math.sin(a)*dist;
        ctx.fillStyle = i%2 ? '#7a5031' : '#d39e62';
        ctx.beginPath();
        ctx.arc(START_X+dx, START_Y+dy, Math.max(2,4-i*.45+kick*1.2), 0, Math.PI*2);
        ctx.fill();
      }
      ctx.restore();
    }

    drawSpeechBubble(ctx,102,346,state.mascotLine);
    if(showFront){
      drawFrontMascot(ctx,55,436,1.04,state.time);
    }else{
      drawBackMascot(ctx,56,436,1.06,state.time,charge,kick);
    }
  }

  function drawToilet(t,highlight){
    ctx.save();ctx.translate(t.x,t.y);if(highlight){ctx.shadowColor='#62d65a';ctx.shadowBlur=16}
    ctx.fillStyle='#faf7ee';ctx.strokeStyle='#60727a';ctx.lineWidth=3;
    ctx.beginPath();ctx.roundRect(13,-30,t.w-26,38,9);ctx.fill();ctx.stroke();
    ctx.beginPath();ctx.ellipse(t.w/2,22,t.w*.46,19,0,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle=highlight?'#7ee26c':'#89cfdf';ctx.beginPath();ctx.ellipse(t.w/2,21,t.w*.34,11,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#faf7ee';ctx.beginPath();ctx.moveTo(11,25);ctx.quadraticCurveTo(15,73,t.w*.36,t.h);ctx.lineTo(t.w*.68,t.h);ctx.quadraticCurveTo(t.w-8,65,t.w-5,25);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();
  }

  function drawObstacles(lv){for(const o of (lv.obstacles||[])){if(o.broken)continue;ctx.fillStyle='#f8f5ef';ctx.strokeStyle='#aaa19a';ctx.lineWidth=3;ctx.fillRect(o.x,o.y,o.w,o.h);ctx.strokeRect(o.x,o.y,o.w,o.h);for(let y=o.y+8;y<o.y+o.h;y+=13){ctx.strokeStyle='#d8d1ca';ctx.beginPath();ctx.moveTo(o.x+2,y);ctx.lineTo(o.x+o.w-2,y);ctx.stroke()}}}
  function drawWind(lv){if(Math.abs(lv.wind)<.012)return;ctx.save();ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=2;const dir=Math.sign(lv.wind);for(let i=0;i<4;i++){const y=115+i*52,x=dir>0?65:325;ctx.beginPath();ctx.moveTo(x,y);ctx.quadraticCurveTo(195,y-20,x+dir*120,y);ctx.stroke();ctx.beginPath();ctx.moveTo(x+dir*120,y);ctx.lineTo(x+dir*106,y-7);ctx.moveTo(x+dir*120,y);ctx.lineTo(x+dir*106,y+7);ctx.stroke()}ctx.restore()}
  function drawTrajectory(pts,hit,visible){if(!visible||state.projectile)return;ctx.save();ctx.fillStyle=hit?'rgba(66,190,70,.78)':'rgba(74,51,38,.34)';pts.slice(0,22).forEach((p,i)=>{ctx.globalAlpha=.9-i*.025;ctx.beginPath();ctx.arc(p.x,p.y,3,0,Math.PI*2);ctx.fill()});ctx.restore()}

  function drawPoop(c,x,y,type,scale=1,rot=0,time=0){
    c.save();c.translate(x,y);c.rotate(rot);c.scale(scale,scale);c.lineJoin='round';c.lineCap='round';c.strokeStyle=type.accent;c.lineWidth=2;
    if(type.shape==='rocket'){
      c.fillStyle=type.body;c.beginPath();c.ellipse(0,1,11,18,0,0,Math.PI*2);c.fill();c.stroke();c.fillStyle=type.accent;c.beginPath();c.arc(0,-15,7,Math.PI,0);c.fill();c.fillStyle='#fff';c.beginPath();c.arc(-4,-2,2.6,0,Math.PI*2);c.arc(4,-2,2.6,0,Math.PI*2);c.fill();c.fillStyle='#3c2730';c.beginPath();c.arc(-4,-2,1,0,Math.PI*2);c.arc(4,-2,1,0,Math.PI*2);c.fill();
    } else if(type.shape==='banana'){
      c.fillStyle=type.body;c.beginPath();c.arc(-1,4,15,.3,Math.PI*1.7);c.quadraticCurveTo(16,-8,9,-18);c.quadraticCurveTo(2,-10,-8,-8);c.closePath();c.fill();c.stroke();face(c,-1,1);
    } else if(type.shape==='chunky'){
      c.fillStyle=type.body;c.beginPath();c.roundRect(-16,-14,32,30,9);c.fill();c.stroke();c.fillStyle=type.accent;for(const q of [[-8,-7],[7,-4],[-3,8],[9,9]]){c.beginPath();c.arc(q[0],q[1],2.2,0,Math.PI*2);c.fill()}face(c,0,0);
    } else if(type.shape==='fire'||type.shape==='meteor'){
      c.fillStyle=type.accent;c.beginPath();for(let i=0;i<16;i++){const a=i*Math.PI/8,r=i%2?13:21;c.lineTo(Math.cos(a)*r,Math.sin(a)*r)}c.closePath();c.fill();c.fillStyle=type.body;c.beginPath();c.arc(0,0,13,0,Math.PI*2);c.fill();face(c,0,0);
    } else if(type.shape==='bubble'){
      c.fillStyle=type.body;c.beginPath();c.arc(0,2,16,0,Math.PI*2);c.fill();c.stroke();c.fillStyle=type.accent;c.globalAlpha=.8;for(const q of [[-9,-10],[8,-14],[13,4]]){c.beginPath();c.arc(q[0],q[1],4,0,Math.PI*2);c.fill()}c.globalAlpha=1;face(c,0,2);
    } else if(type.shape==='smooth'){
      c.fillStyle=type.body;c.beginPath();c.moveTo(-16,12);c.quadraticCurveTo(-19,1,-9,-2);c.quadraticCurveTo(-14,-12,-2,-11);c.quadraticCurveTo(-1,-22,7,-14);c.quadraticCurveTo(20,-9,13,1);c.quadraticCurveTo(21,9,11,14);c.closePath();c.fill();c.stroke();c.fillStyle=type.accent;c.beginPath();c.ellipse(-5,-8,5,3,-.4,0,Math.PI*2);c.fill();face(c,1,2);
    } else if(type.shape==='drops'){
      c.fillStyle=type.body;c.beginPath();c.moveTo(0,-20);c.bezierCurveTo(18,0,15,17,0,18);c.bezierCurveTo(-15,17,-18,0,0,-20);c.fill();c.stroke();c.fillStyle=type.accent;c.beginPath();c.arc(-13,8,5,0,Math.PI*2);c.arc(13,11,4,0,Math.PI*2);c.fill();face(c,0,3);
    } else if(type.shape==='popcorn'){
      c.fillStyle=type.body;c.beginPath();c.arc(0,5,14,0,Math.PI*2);c.fill();c.stroke();c.fillStyle=type.accent;for(const q of [[-9,-10],[0,-15],[9,-10],[-2,-5]]){c.beginPath();c.arc(q[0],q[1],6,0,Math.PI*2);c.fill();c.stroke()}face(c,0,5);
    } else {
      c.fillStyle=type.body;c.beginPath();c.moveTo(-15,13);c.quadraticCurveTo(-20,2,-10,-2);c.quadraticCurveTo(-15,-11,-4,-12);c.quadraticCurveTo(-3,-23,4,-15);c.quadraticCurveTo(17,-12,11,-3);c.quadraticCurveTo(21,5,14,13);c.closePath();c.fill();c.stroke();face(c,0,1);
    }
    c.restore();
  }
  function face(c,x,y){c.fillStyle='#fff';c.beginPath();c.arc(x-5,y-2,3,0,Math.PI*2);c.arc(x+5,y-2,3,0,Math.PI*2);c.fill();c.fillStyle='#3c2a22';c.beginPath();c.arc(x-5,y-2,1.2,0,Math.PI*2);c.arc(x+5,y-2,1.2,0,Math.PI*2);c.fill();c.strokeStyle='#3c2a22';c.lineWidth=1.5;c.beginPath();c.arc(x,y+3,4,.1,Math.PI-.1);c.stroke()}
  function drawMini(){const c=$('#miniPoop').getContext('2d');c.clearRect(0,0,28,28);drawPoop(c,14,15,state.type,.65,0,0)}

  let last=0,raf=0;
  function loop(ts){if(state.screen!=='#gameScreen'){cancelAnimationFrame(raf);return}if(state.paused){raf=requestAnimationFrame(loop);return}const dt=Math.min(2,(ts-last)/16.67||1);last=ts;update(dt);draw();raf=requestAnimationFrame(loop)}

  function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(t._x);t._x=setTimeout(()=>t.classList.remove('show'),1500)}

  function openCollection(){
    const list=$('#collectionList');list.innerHTML='';Object.values(types).forEach(t=>{const unlocked=state.discovered.has(t.id);const d=document.createElement('div');d.className='collect-item'+(unlocked?'':' locked');const cv=document.createElement('canvas');cv.width=45;cv.height=45;const tx=document.createElement('div');tx.innerHTML=`<div class="collect-name">${unlocked?t.name:'？？？'}</div><div class="collect-desc">${unlocked?t.tag:'继续混合食物解锁'}</div>`;d.append(cv,tx);list.appendChild(d);if(unlocked)drawPoop(cv.getContext('2d'),22,24,t,.8,0,0)});
    $('#collectionCount').textContent=`已发现 ${state.discovered.size} / ${Object.keys(types).length} 种便便`;$('#collectionModal').classList.add('show');
  }

  $('#continueBtn').addEventListener('click',()=>{audio.ensure();audio.click();state.level=Math.min(state.level,state.unlocked-1);openLab()});
  $('#recipeBtn').addEventListener('click',()=>{audio.ensure();openLab()});
  $('#collectionBtn').addEventListener('click',()=>{audio.ensure();openCollection()});
  $('#closeCollection').addEventListener('click',()=>$('#collectionModal').classList.remove('show'));
  $('#labBack').addEventListener('click',()=>{audio.click();showScreen('#menuScreen');buildLevels()});
  $('#randomMix').addEventListener('click',()=>{audio.ensure();const ids=foods.map(f=>f.id).sort(()=>Math.random()-.5);state.selected=ids.slice(0,2);updateLab();audio.mix()});
  $('#useRecipe').addEventListener('click',()=>{audio.ensure();if(!requirementOK()){audio.fail();toast('请先合成本关指定配方');return}state.discovered.add(state.type.id);saveGame();startLevel()});
  $('#gameHome').addEventListener('click',()=>{endSession('quit');$('#resultModal').classList.remove('show');showScreen('#menuScreen');buildLevels()});
  $('#soundBtn').addEventListener('click',()=>{if(!state.sound){state.sound=true;audio.ensure();if(!state.paused)audio.startMusic()}else{state.sound=false;audio.stopMusic()}$('#soundBtn').textContent=state.sound?'🔊':'🔇'});
  const hold=$('#holdBtn');hold.addEventListener('pointerdown',chargeStart);window.addEventListener('pointerup',chargeEnd);window.addEventListener('pointercancel',chargeEnd);hold.addEventListener('contextmenu',e=>e.preventDefault());hold.addEventListener('touchstart',e=>e.preventDefault(),{passive:false});
  hold.addEventListener('contextmenu',e=>e.preventDefault());
  window.addEventListener('keydown',e=>{if(e.code==='Space'&&!e.repeat&&state.screen==='#gameScreen'){e.preventDefault();chargeStart(e)}});window.addEventListener('keyup',e=>{if(e.code==='Space'&&state.screen==='#gameScreen'){e.preventDefault();chargeEnd(e)}});
  $('#retryBtn').addEventListener('click',()=>{$('#resultModal').classList.remove('show');state.attempts=0;resetShot(true)});
  $('#nextBtn').addEventListener('click',()=>{$('#resultModal').classList.remove('show');state.level=Math.min(levels.length-1,state.level+1);startLevel()});
  $('#changeRecipeBtn').addEventListener('click',()=>{$('#resultModal').classList.remove('show');openLab()});


  window.addEventListener('keydown',e=>{
    if(e.code==='KeyM'){e.preventDefault();$('#soundBtn').click()}
    if(e.code==='KeyR'&&state.screen==='#gameScreen'&&!state.launched){e.preventDefault();resetShot()}
  });

  document.addEventListener('visibilitychange',()=>{
    if(document.hidden) pauseGame('visibility_hidden');
    else resumeGame('visibility_visible');
  });
  window.addEventListener('blur',()=>pauseGame('window_blur'));
  window.addEventListener('focus',()=>resumeGame('window_focus'));
  window.addEventListener('panpan:pause',()=>pauseGame('host'));
  window.addEventListener('panpan:resume',()=>resumeGame('host'));
  window.addEventListener('panpan:audio-change',event=>setMuted(Boolean(event.detail&&event.detail.muted)));
  window.addEventListener('panpan:host-init',event=>setMuted(Boolean(event.detail&&event.detail.muted)));
  window.addEventListener('beforeunload',()=>endSession('quit'));

  window.addEventListener('error',function(event){
    window.PanPanGame?.error({code:'UNHANDLED_ERROR',message:event.message||'未知错误',fatal:false});
  });
  window.addEventListener('unhandledrejection',function(event){
    window.PanPanGame?.error({code:'UNHANDLED_PROMISE_REJECTION',message:String(event.reason||'未知异步错误'),fatal:false});
  });

  buildLevels();buildFoods();updateLab();
  window.PanPanGame?.ready({gameVersion:'1.0.0'});
})();