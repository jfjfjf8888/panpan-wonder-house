# 《拉了坨大的》1.0.0 交付说明

## 游戏玩法简介
选择两种食物合成不同属性的便便，等待自动角度摆动，按住蓄力、松手发射，让便便落入不同场景的马桶。第五关起需使用指定配方。

## 后台展示一句话介绍
合成邪修配方，蓄力发射不同属性的便便，挑战离谱马桶关卡。

## 游戏操作说明
- 触摸/鼠标：选择食物；按住蓄力按钮，松手发射。
- 键盘：空格键蓄力与发射，M 静音，R 重置投射。

## ZIP 内文件清单
- `README.md`
- `cover.webp`
- `css/game.css`
- `icon.png`
- `index.html`
- `js/game-bridge.js`
- `js/game.js`
- `manifest.json`
- `screenshots/01.webp`
- `screenshots/02.webp`

## manifest.json
```json
{
  "schemaVersion": "1.0",
  "id": "la-le-tuo-da-de",
  "slug": "la-le-tuo-da-de",
  "title": "拉了坨大的",
  "shortDescription": "合成邪修配方，蓄力发射不同属性的便便，挑战离谱马桶关卡。",
  "description": "一款轻松魔性的物理闯关小游戏。玩家从小油油拿铁、西梅汁、香蕉、酸奶等食物中选择两种进行合成，生成不同速度、重量、弹性与特殊能力的便便。控制自动摆动的发射角度，按住蓄力、松手发射，让便便准确落入移动、高空、强风和失重场景中的马桶。第五关起需要使用指定配方，失败还会触发粑粑雨、弹弹派对等趣味特效。",
  "version": "1.0.0",
  "author": "PanPan Lab",
  "entry": "index.html",
  "cover": "cover.webp",
  "icon": "icon.png",
  "tags": [
    "休闲",
    "物理",
    "合成",
    "闯关",
    "搞笑"
  ],
  "orientation": "any",
  "controls": [
    "touch",
    "mouse",
    "keyboard"
  ],
  "display": {
    "aspectRatio": "9:16",
    "minWidth": 320,
    "maxWidth": 1920,
    "supportsFullscreen": false
  },
  "permissions": {
    "audio": true,
    "storage": true,
    "fullscreen": false,
    "networkDomains": []
  },
  "analytics": {
    "enabled": true
  },
  "adCapabilities": {
    "banner": false,
    "interstitial": true,
    "rewarded": true
  }
}
```

## 自检结果
- [x] ZIP 根目录包含 index.html
- [x] ZIP 根目录包含 manifest.json
- [x] ZIP 根目录包含 cover.webp
- [x] 存在 js/game-bridge.js
- [x] manifest 合法 JSON
- [x] manifest entry 存在：index.html
- [x] manifest cover 存在：cover.webp
- [x] manifest icon 存在：icon.png
- [x] id/slug 符合规则
- [x] 版本号符合规则：1.0.0
- [x] 无外部 CDN / URL
- [x] 无 eval/new Function
- [x] GAME_READY 已实现
- [x] GAME_START 已实现
- [x] GAME_END 已实现
- [x] 错误上报已实现
- [x] 触摸操作已实现
- [x] 鼠标操作已实现
- [x] 键盘操作已实现
- [x] 320px 测试通过：scrollWidth=clientWidth=320
- [x] 声音需首次交互后启动：Web Audio 仅在玩家点击/触摸后 ensure()
- [x] 静音能力已实现
- [x] 页面隐藏后暂停
- [x] 广告关闭不影响游戏：游戏完整支持无广告运行
- [x] 封面尺寸/大小符合
- [x] 无禁止文件
- [x] 浏览器运行冒烟测试通过：无控制台错误；收到 GAME_READY/GAME_START/GAME_PAUSE/GAME_RESUME/GAME_END

## 已知问题
- 旧浏览器不支持 Web Audio API 时自动静音，但不影响游玩。
- 横屏可运行，但竖屏体验更好。

## 1.0.0 更新内容
- 首次按网站规范完成正式游戏包。
- 拆分 CSS、主脚本和网站通信桥接脚本。
- 接入游戏开始、暂停、恢复、得分、关卡完成、结束与错误事件。
- 增加安全区域、320px 适配、页面后台暂停与命名空间存档。
- 增加封面、图标、截图、README 和完整 manifest。
